package com.example.foodbook.pojo

data class CategoryList(
    val categories: List<Category>
)