package com.example.foodbook.pojo

data class MealList(
    val meals: List<Meal>
)