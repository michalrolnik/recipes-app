package com.example.foodbook.pojo

data class MealsByCategory(
    val idMeal: String,
    val strMeal: String,
    val strMealThumb: String
)