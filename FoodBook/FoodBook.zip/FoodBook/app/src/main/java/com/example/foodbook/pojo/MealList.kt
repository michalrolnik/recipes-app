package com.example.foodbook.pojo
//This generated with plugin :kotlin data class from json

data class MealList(
    val meals: List<Meal>
)