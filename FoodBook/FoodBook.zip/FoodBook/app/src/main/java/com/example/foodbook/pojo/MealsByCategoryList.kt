package com.example.foodbook.pojo

data class MealsByCategoryList(
    val meals: List<MealsByCategory>
)